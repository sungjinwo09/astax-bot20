# Astax Store Bot

Bot Telegram automatik untuk ambil order dan hantar notifikasi kepada seller.

## Cara deploy ke Render

1. Upload semua fail ini ke GitHub.
2. Pergi ke [Render.com](https://render.com/).
3. Pilih "New Web Service".
4. Connect ke repo GitHub projek ini.
5. Set:

```
Build Command: pip install -r requirements.txt
Start Command: python main.py
```

6. Deploy dan siap.

## Dibina dengan
- Python
- pyTelegramBotAPI