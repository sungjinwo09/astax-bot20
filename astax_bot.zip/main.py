import telebot

TOKEN = 'YOUR_BOT_TOKEN'
SELLER_ID = 7257564750
bot = telebot.TeleBot(TOKEN)

order_data = {}

@bot.message_handler(commands=['start'])
def welcome(message):
    bot.send_message(
        message.chat.id,
        "🔥 Hai Selamat Datang ke Astax Store!\n"
        "📦 Untuk buat order, tekan (/order)\n"
        "📝 Nak tengok *pricelist*? Join group ini:\n"
        "👉 https://t.me/PriceListAstaxBot",
        parse_mode="Markdown"
    )

@bot.message_handler(commands=['order'])
def start_order(message):
    bot.send_message(
        message.chat.id,
        "📝 Sila hantar maklumat order anda dalam format berikut:\n\n"
        "`NAMA TELEGRAM`\n`PRODUK`\n`USER ID`\n`SERVER ID (Jika perlu)`\n`TARIKH (cth: 17/04/2025)`\n\n"
        "*Contoh:* \n"
        "`Ilhan`\n`DM ML 86 Diamonds`\n`123456789`\n`2000`\n`17/04/2025`",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(message, collect_order)

def collect_order(message):
    lines = message.text.strip().split("\n")
    if len(lines) < 5:
        bot.reply_to(message, "❌ Sila isi semua 5 maklumat yang diminta.")
        return

    user_id = message.from_user.id
    order_data[user_id] = {
        'nama': lines[0],
        'produk': lines[1],
        'userid': lines[2],
        'server': lines[3],
        'tarikh': lines[4],
        'message_id': message.message_id,
        'chat_id': message.chat.id
    }

    bot.send_message(
        message.chat.id,
        "💳 *Sila buat bayaran ke salah satu akaun berikut:*\n\n"
        "📲 *Touch 'n Go eWallet*\n"
        "🔢 No: `011-18751747`\n"
        "👤 Nama: *ILHAN IZZARIL*\n\n"
        "💰 Untuk pembayaran *RM40 dan ke atas:*\n"
        "🏦 *MAYBANK*\n"
        "🔢 No: `155087317503`\n"
        "👤 Nama: *ILHAN IZZARIL*\n\n"
        "📸 *Sila hantar gambar resit pembayaran di sini.*",
        parse_mode="Markdown"
    )

@bot.message_handler(content_types=['photo'])
def handle_receipt(message):
    user_id = message.from_user.id
    if user_id not in order_data:
        bot.reply_to(message, "⚠️ Sila buat order dulu guna /order")
        return

    data = order_data[user_id]

    caption = (
        "🆙️ *Order Baru Diterima!*\n\n"
        f"👤 Nama Telegram: {data['nama']}\n"
        f"📦 Produk: {data['produk']}\n"
        f"🆔 User ID: {data['userid']}\n"
        f"🌐 Server ID: {data['server']}\n"
        f"🗓 Tarikh: {data['tarikh']}\n\n"
        "📌 *Resit pembayaran dilampirkan.*"
    )

    bot.send_photo(SELLER_ID, message.photo[-1].file_id, caption=caption, parse_mode="Markdown")
    bot.reply_to(message,
        "✅ Terima kasih! Resit anda telah dihantar kepada seller.\n\n"
        "⏳ *Order anda sedang diproses.*\n"
        "Sila tunggu pengesahan daripada seller ya!"
    )

@bot.message_handler(commands=['doneorder'])
def handle_done_order(message):
    if not message.reply_to_message:
        bot.reply_to(message, "❌ Sila reply pada mesej order customer untuk guna arahan ini.")
        return

    replied_user_id = message.reply_to_message.from_user.id

    if replied_user_id not in order_data:
        bot.reply_to(message, "⚠️ Data order tidak dijumpai.")
        return

    data = order_data[replied_user_id]

    msg = (
        "✅ *Order anda sudah diterima!*\n\n"
        f"📦 Produk: {data['produk']}\n"
        f"🖔 Server + ID: {data['server']} | {data['userid']}\n"
        f"🗓 Tarikh: {data['tarikh']}\n\n"
        "🔍 Sila semak akaun anda dan pastikan order telah diterima.\n\n"
        "❗ Jika ada sebarang masalah, sila hubungi admin:\n"
        "📩 @SakuragiYaeka01"
    )

    bot.send_message(replied_user_id, msg, parse_mode="Markdown")
    bot.reply_to(message, "✉ Notifikasi telah dihantar kepada pembeli.")

bot.infinity_polling()